# Alfred Puppet Module for Boxen

Install [Alfred](http://www.alfredapp.com), a productivity app for Mac OS X.

## Usage

```puppet
include alfred
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
